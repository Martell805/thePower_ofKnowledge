import pygame
from Classes import *
from Defs import *


class Blank:
    def __init__(self):
        self.include = {'buttons': pygame.sprite.Group(),
                        'all': pygame.sprite.Group(),
                        'lables': [],
                        'fon': pygame.sprite.Group(),
                        'screen': pygame.Surface((300, 550))}

        self.fon = Fon(300, 550, load_image('blank.png', -1), self.include['fon'])

        self.lable1 = Label(80, 100, "РАБОТА", color=(0, 0, 0), size=10)
        self.include['lables'].append(self.lable1)

        self.fiz = Button(0, 200, 100, 100, load_image('fizzn.png', -1), self.include['all'], self.include['buttons'])
        self.fiz.connect(self.d_fiz)

        self.math = Button(100, 200, 100, 100, load_image('mathzn.png', -1), self.include['all'], self.include['buttons'])
        self.math.connect(self.d_math)

        self.chem = Button(200, 200, 100, 100, load_image('chemzn.png', -1), self.include['all'], self.include['buttons'])
        self.chem.connect(self.d_chem)

        self.stp = Button(100, 350, 90, 30, load_image('declineZN.png', -1), self.include['all'],self.include['buttons'])
        self.stp.connect(self.d_zn)

        self.ext = Button(0, 90, 50, 50, load_image('back.png', -1), self.include['all'], self.include['buttons'])
        self.ext.connect(self.d_blank)

    def update(self, pos, *args):
        self.include['buttons'].update((pos[0], pos[1]), args)

    def draw(self):
        if (open("env/route.data",'r').read() != "none"):  #-----------------------------------------------------------добавить графику для залоченых кнопок
            self.math.disable()
            self.chem.disable()
            self.fiz.disable()
            self.stp.enable()
        else:
            self.math.enable()
            self.fiz.disable()
            self.chem.disable()
            self.stp.disable()
        self.include['fon'].draw(self.include['screen'])
        self.include['all'].draw(self.include['screen'])
        for q in self.include['lables']:
            q.draw(self.include['screen'])

    def d_blank(self, *args):
        f = open('settings/blank_enabled.data', 'w')
        f.write('0')
        f.close()

    def d_math(self, *args):
        f = open('settings/quest.data', 'w')
        f.write('mat')
        f.close()
        self.go_zn()

    def d_fiz(self, *args):
        f = open('settings/quest.data', 'w')
        f.write('phy')
        f.close()
        self.go_zn()

    def d_chem(self, *args):
        f = open('settings/quest.data', 'w')
        f.write('che')
        f.close()
        self.go_zn()

    def d_zn(self, *args): # ---------------------------------------------- кнопка отключения задания, обнуляет почти весь env (среда)
        f = open ('env/questDisc.data', 'w')
        f.write('empty')
        f.close()
        f = open('env/route.data', 'w')
        f.write('none')
        f.close()
        f = open('settings/blank_enabled.data', 'w')
        f.write('0')
        f.close()

    def go_zn(self, *args): # ----------------------------------------------- переход к холсту с заданием, выход из бланка
        #print(1)
        f = open('settings/zn_enabled.data', 'w')
        f.write('1')
        f.close()
        f = open('settings/blank_enabled.data', 'w')
        f.write('0')
        f.close()
