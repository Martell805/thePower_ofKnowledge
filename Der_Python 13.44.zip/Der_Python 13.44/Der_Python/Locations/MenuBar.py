import pygame
from Classes import *
from Defs import *


class MenuBar:
    def __init__(self):
        self.include = {'buttons': pygame.sprite.Group(),
                        'all': pygame.sprite.Group(),
                        'lables': [],
                        'fon': pygame.sprite.Group(),
                        'screen': pygame.Surface((300, 50))}

        self.fon = Fon(300, 50, load_image('menu_bar.png', -1), self.include['fon'])

        self.lable1 = Label(110, 10, "POK", color=(255, 255, 255), size=50)
        self.include['lables'].append(self.lable1)

        self.book = Button(10, 0, 50, 50, load_image('booksmall.png', -1), self.include['all'], self.include['buttons'])
        self.book.connect(self.d_book)

        self.menu = Button(240, 0, 50, 50, load_image('menu.png', -1), self.include['all'], self.include['buttons'])
        self.menu.connect(self.d_exit)

    def update(self, pos, *args):
        self.include['buttons'].update(pos, args)

    def draw(self):
        self.include['fon'].draw(self.include['screen'])
        self.include['all'].draw(self.include['screen'])
        for q in self.include['lables']:
            q.draw(self.include['screen'])

    def d_book(self, *args):
        f = int(open('settings/book_enabled.data', 'r').read())
        if f:
            f = open('settings/book_enabled.data', 'w')
            f.write('0')
            f.close()
        else:
            f = open('settings/book_enabled.data', 'w')
            f.write('1')
            f.close()

    def d_exit(self, *args):
        f = open('settings/location.data', 'w')
        f.write('map')
        f.close()
        f = open('settings/book_enabled.data', 'w')
        f.write('0')
        f.close()
        f = open('settings/book_enabled.data', 'w')
        f.write('0')
        f.close()
        f = open('settings/quest.data', 'w')
        f.write('NONE')
        f.close()
        f = open('settings/battle.data', 'w')
        f.write('-1')
        f.close()
        terminate()
