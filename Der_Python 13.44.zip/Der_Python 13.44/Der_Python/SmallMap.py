import pygame
from Classes import *
from Defs import *


class SmallMap:
    def __init__(self):
        self.include = {'buttons': pygame.sprite.Group(),
                        'all': pygame.sprite.Group(),
                        'lables': [],
                        'fon': pygame.sprite.Group(),
                        'screen': pygame.Surface((300, 550))}

        self.fon = Fon(300, 550, load_image('smallmap.png'), self.include['fon'])

        #self.lable1 = Label(100, 0, "POK", color=(255, 255, 255), size=20)
        #self.include['lables'].append(self.lable1)

        self.mountain = Button(0, 0, 139, 188, load_image('tavern.png', -1), self.include['all'], self.include['buttons'])
        self.mountain.connect(lambda x: print('Its tavern'))

        self.town = Button(125, 250, 139, 188, load_image('baraholka.png', -1), self.include['all'], self.include['buttons'])
        self.town.connect(lambda x: print('Its baraholka'))

        self.swamp = Button(150, 0, 38, 39, load_image('smallexit.png', -1), self.include['all'], self.include['buttons'])
        self.swamp.connect(lambda x: print('Its swamp'))

        self.forest = Button(150, 500, 25, 39, load_image('boardOfHonor.png', -1), self.include['all'], self.include['buttons'])
        self.forest.connect(lambda x: print('Its board'))

    def update(self, pos, *args):
        self.include['buttons'].update(pos, args)

    def draw(self):
        self.include['all'].draw(self.include['screen'])
        for q in self.include['lables']:
            q.draw(self.include['screen'])
