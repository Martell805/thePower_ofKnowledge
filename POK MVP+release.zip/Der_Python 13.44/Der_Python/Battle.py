import pygame
from Defs import *
from Classes import *
import random


class Battle:
    def __init__(self, player, screen):
        self.gl_screen = screen
        self.enemy_gr = pygame.sprite.Group()
        self.loca = open('env/route.data')
        self.palyer = player
        self.enemy = Enemy(100, 100, 100, 100, load_image('enemy1.png', -1),
                           1, random.randint(2, 4), random.randint(0, 6), self.enemy_gr)
        f = open('settings/battle.data', 'w')
        f.write('0')

    def turn(self, pos):
        self.all_sprites = pygame.sprite.Group()
        self.buttons = pygame.sprite.Group()
        self.screen = pygame.Surface((300, 550))
        self.screen.fill((0, 0, 0))
        disc = open('settings/quest.data', 'r').read()

        self.fone_gr = pygame.sprite.Group()
        if (open('env/route.data', 'r').read() == "mountain"):
            self.fon = Fon(300, 550, load_image('mount_fon.png', -1), self.fone_gr)
        elif (open('env/route.data', 'r').read() == "swamp"):
            self.fon = Fon(300, 550, load_image('swamp_fon.png', -1), self.fone_gr)
        else:
            self.fon = Fon(300, 550, load_image('battle_fon.png', -1), self.fone_gr)
        lvl = str(int(open(disc + '/num.txt', 'r').read())%3)
        pathh = disc + '/answers/' + lvl + '.txt'
        anss = open(pathh, 'r').readlines()
        r_ans = anss[0]

        pathh = disc + '/tasks/' + lvl + '.txt'
        task = open(pathh, 'r', encoding='utf-8').read()


        self.lables = []
        self.lables.append(Label(10, 265, task, self.all_sprites, color=(255, 255, 255), size=15))
        self.lables.append(Label(40, 405, anss[0], self.all_sprites, color=(255, 255, 255), size=30))
        self.lables.append(Label(40, 445, anss[1], self.all_sprites, color=(255, 255, 255), size=30))
        self.lables.append(Label(40, 485, anss[2], self.all_sprites, color=(255, 255, 255), size=30))

        self.button1 = Button(5, 395, 100, 40, load_image('button.png'), self.all_sprites, self.buttons)
        self.button1.connect(self.ra)
        self.button2 = Button(5, 435, 100, 40, load_image('button.png'), self.all_sprites, self.buttons)
        self.button2.connect(self.wa)
        self.button3 = Button(5, 475, 100, 40, load_image('button.png'), self.all_sprites, self.buttons)
        self.button3.connect(self.wa)

        self.buttons.update(pos)

        self.fone_gr.draw(self.screen)
        self.all_sprites.draw(self.screen)
        for q in self.lables:
            q.draw(self.screen)
        self.enemy_gr.draw(self.screen)
        self.gl_screen.blit(self.screen, (0, 0))

    def ra(self):
        f = open('env/route.data', 'w')
        f.write('none')
        f.close()
        f = open('env/questDisc.data', 'w')
        f.write('empty')
        f.close()
        disc = open('settings/quest.data', 'r').read()
        lvl = int(open(disc + '/num.txt', 'r').read())+ 1
        kol = int(open('settings/money.data', 'r').read())+lvl
        f = open('settings/money.data', 'w')
        f.write(str(kol))
        f.close()
        f = open(disc + '/num.txt', 'w')
        f.write(str(lvl))
        f.close()

        f = open('settings/battle.data', 'w')
        f.write('1')
        f.close()

    def wa(self):
        f = open('settings/battle.data', 'w')
        f.write('1')
        f.close()
