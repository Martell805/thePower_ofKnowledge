import pygame
from Classes import *
from Defs import *


class Book:
    def __init__(self):
        self.include = {'buttons': pygame.sprite.Group(),
                        'all': pygame.sprite.Group(),
                        'lables': [],
                        'fon': pygame.sprite.Group(),
                        'screen': pygame.Surface((300, 300))}

        self.fon = Fon(300, 300, load_image('book.jpg', -1), self.include['fon'])

        self.lable1 = Label(5, 190, 'Quest: ' + open('settings/quest.data').read(), color=(0, 0, 0), size=20)
        self.include['lables'].append(self.lable1)
        self.lable2 = Label(15, 10, 'Money: ' + open('settings/money.data', 'r').read(), color=(0, 0, 0), size=20)
        self.include['lables'].append(self.lable2)
    def update(self, pos, *args):
        self.include['buttons'].update(pos, args)

    def draw(self):
        if (open('env/questDisc.data').read() != "empty"):
            self.lable1.set_text('    Quest: ' + open('env/questDisc.data').read() +
'''
    Location: ''' + open('env/route.data', 'r').read())
        else:
            self.lable1.set_text('''
    У Вас нет
    активных квестов
    (Получить квест
     можно в таверне)''')
        self.lable2.set_text(('Money: ' + open('settings/money.data', 'r').read()))
        self.include['fon'].draw(self.include['screen'])
        self.include['all'].draw(self.include['screen'])
        for q in self.include['lables']:
            q.draw(self.include['screen'])
