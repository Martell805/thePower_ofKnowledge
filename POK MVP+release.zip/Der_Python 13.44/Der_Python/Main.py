from Defs import *
from Classes import *
from Locations.Map import Map
from Locations.Town import Town
from Locations.MenuBar import MenuBar
from Locations.Book import Book
from Locations.Blank import Blank
from Locations.znShablon import znShablon
from Locations.lection import lection
from Battle import Battle
import pygame

pygame.init()

if(open('settings/quest.data', 'r').read()=="NONE"): #----------------------------------------------------очень жесткий костыль - надо придумать как пофиксить
    f = open('settings/quest.data', 'w')
    f.write('mat')
    f.close()

screen = pygame.display.set_mode((300, 550))
pygame.mouse.set_visible(True)
pygame.display.set_caption('D_P')

locations = {'map': Map(),
             'town': Town()}
menu_bar = MenuBar()
book = Book()
blank = Blank()
zn = znShablon()

player = Player(50, 50, load_image('enemy1.png', -1), 6, 6, 6, load_invent('player_info/invent.data'))
lect = lection()

running = True
battle_going = False
battle_nft = True
f = open('settings/zn_enabled.data', 'w')
f.write('0')
f.close()
f = open('settings/battle.data', 'w')
f.write('-1')
f.close()
f = open('settings/lect.data', 'w')
f.write('0')
f.close()
f = open('settings/location.data', 'w')
f.write('town')
f.close()
f = open('settings/book_enabled.data', 'w')
f.write('0')
f.close()
f = open('settings/blank_enabled.data', 'w')
f.write('0')
f.close()
f = open('env/route.data', 'w')
f.write('none')
f.close()
f = open('env/questDisc.data', 'w')
f.write('empty')
f.close()

while running:
    loca = open('settings/location.data').read()
    for event in pygame.event.get():
        poses = []
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            poses.append(event.pos)
            menu_bar.update(event.pos)
            if int(open('settings/blank_enabled.data', 'r').read()):
                blank.update(event.pos)
            elif int(open('settings/book_enabled.data', 'r').read()):
                book.update(event.pos)
            elif int(open('settings/zn_enabled.data', 'r').read()):
                zn.update(event.pos)
            elif int(open('settings/lect.data', 'r').read()):
                lect.update(event.pos)
            else:
                locations[loca].update(event.pos)

    locations[loca].draw()
    screen.blit(locations[loca].include['screen'], (0, 0))
    battle_not_going = bool(int(open('settings/battle.data').read()))
    if not battle_not_going:
        if battle_nft:
            battle_nft = False
            battle = Battle(player, screen)
        battle.turn((-100, -100))
        for q in poses:
            battle.turn(q)
    else:
        battle_nft = True
    menu_bar.draw()
    screen.blit(menu_bar.include['screen'], (0, 0))
    book.draw()
    if int(open('settings/book_enabled.data', 'r').read()):
        screen.blit(book.include['screen'], (0, 100))
    blank.draw()
    if int(open('settings/blank_enabled.data', 'r').read()):
        screen.blit(blank.include['screen'], (0, 0))
    zn.draw()
    if int(open('settings/zn_enabled.data', 'r').read()):
        screen.blit(zn.include['screen'], (0, 0))
    lect.draw()
    if int(open('settings/lect.data', 'r').read()):
        screen.blit(lect.include['screen'], (0, 50))
    pygame.display.flip()

print('Работа завершена...')
terminate()
