import pygame

print(*pygame.font.get_fonts(), sep='\n')
