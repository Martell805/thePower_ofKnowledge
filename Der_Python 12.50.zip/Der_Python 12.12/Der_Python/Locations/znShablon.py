import pygame
from Classes import *
from Defs import *


class znShablon:
    def __init__(self):
        self.include = {'buttons': pygame.sprite.Group(),
                        'all': pygame.sprite.Group(),
                        'lables': [],
                        'fon': pygame.sprite.Group(),
                        'screen': pygame.Surface((300, 550))}

        self.fon = Fon(300, 550, load_image('znFon.png', -1), self.include['fon'])

        disc = open('settings/quest.data','r').read()
        lvl = open(disc+'/num.txt', 'r').read()
        pathh = disc+'/ads/'+ lvl+'.txt'
        try:
            capt = open(pathh, 'r', encoding='utf-8').read()
        except Exception:
            capt = pathh
        self.lable1 = Label(50, 80, capt, color=(0, 0, 0), size=20)
        self.include['lables'].append(self.lable1)
        lvl = open(disc + '/num.txt', 'r').read()
        pathh = disc + '/minitask/' + lvl + '.txt'
        try:
            tex = open(pathh, 'r').read()
        except Exception:
            tex = pathh
        self.lable2 = Label(50, 110, tex, color=(0, 0, 0), size=20)
        self.include['lables'].append(self.lable2)

        self.ext = Button(0, 90, 50, 50, load_image('back.png', -1), self.include['all'], self.include['buttons'])
        self.ext.connect(self.d_paper)

        self.acpt = Button(100, 500, 90, 30, load_image('acceptBt.png', -1), self.include['all'], self.include['buttons'])
        self.acpt.connect(self.acpt_paper)

    def update(self, pos, *args):
        self.include['buttons'].update((pos[0], pos[1]), args)

    def draw(self):
        disc = open('settings/quest.data', 'r').read()
        lvl = open(disc + '/num.txt', 'r').read()
        pathh = disc + '/ads/' + lvl + '.txt'
        try:
            capt = open(pathh, 'r', encoding='utf-8').read()
        except Exception:
            capt = pathh
        self.lable1.set_text(capt)

        disc = open('settings/quest.data', 'r').read()
        lvl = open(disc + '/num.txt', 'r').read()
        pathh = disc + '/minitask/' + lvl + '.txt'
        try:
            capt = open(pathh, 'r').read()
        except Exception:
            capt = pathh
        #print(capt)
        self.lable2.set_text(capt)

        self.include['fon'].draw(self.include['screen'])
        self.include['all'].draw(self.include['screen'])
        for q in self.include['lables']:
            q.draw(self.include['screen'])

    def d_paper(self, *args):
        f = open('settings/zn_enabled.data', 'w')
        f.write('0')
        f.close()

    def acpt_paper(self, *args):
        f = open('env/questDisc.data', 'w')
        f.write(open('settings/quest.data', 'r').read())
        f.close()
        disc = open('settings/quest.data', 'r').read()
        lvl = open(disc + '/num.txt', 'r').read()
        pathh = disc + '/location/' + lvl + '.txt'
        f = open("env/route.data", 'w')
        f.write(open(pathh, 'r').read())
        f.close()
        f = open('settings/zn_enabled.data', 'w')
        f.write('0')
        f.close()