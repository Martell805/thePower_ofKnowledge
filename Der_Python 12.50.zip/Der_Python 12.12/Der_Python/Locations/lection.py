import pygame
from Classes import *
from Defs import *


class lection:
    def __init__(self):
        self.include = {'buttons': pygame.sprite.Group(),
                        'all': pygame.sprite.Group(),
                        'lables': [],
                        'fon': pygame.sprite.Group(),
                        'screen': pygame.Surface((300, 550))}

        self.fon = Fon(300, 550, load_image('bookVert.jpg', -1), self.include['fon'])

        self.lable1 = Label(70, 60, 'Quest: ' + open('settings/quest.data').read(), color=(0, 0, 0), size=20)
        self.include['lables'].append(self.lable1)

        disc = open('settings/quest.data', 'r').read()
        lvl = open(disc + '/num.txt', 'r').read()
        pathh = disc + '/lections/' + lvl + '.txt'
        tex = open(pathh, 'r').read()

        self.lable2 = Label(10, 100, tex, color=(0, 0, 0), size=20)
        self.include['lables'].append(self.lable2)

        self.butn = Button(200, 450, 90, 30, load_image('acceptBt.png', -1), self.include['all'], self.include['buttons'])
        self.butn.connect(self.goToBattle)

    def update(self, pos, *args):
        self.include['buttons'].update((pos[0], pos[1] - 50), args)

    def draw(self):
        disc = open('settings/quest.data', 'r').read()
        lvl = open(disc + '/num.txt', 'r').read()
        pathh = disc + '/lections/' + lvl + '.txt'
        tex = open(pathh, 'r', encoding='utf-8').read()
        self.lable1.set_text('    Лекция по: ' + open('env/questDisc.data').read() + '''
Место выполнения: ''' + open('env/route.data', 'r').read())
        self.lable2.set_text(tex)
        self.include['fon'].draw(self.include['screen'])
        self.include['all'].draw(self.include['screen'])
        for q in self.include['lables']:
            q.draw(self.include['screen'])

    def goToBattle(self, *args):
        f = open('settings/lect.data', 'w')
        f.write('0')
        f.close()
        f = open('settings/battle.data', 'w')
        f.write('0')
        f.close()
