import pygame
from Classes import *
from Defs import *


class Map:
    def __init__(self):
        self.include = {'buttons': pygame.sprite.Group(),
                        'all': pygame.sprite.Group(),
                        'lables': [],
                        'fon': pygame.sprite.Group(),
                        'screen': pygame.Surface((300, 550))
                        }

        self.fon = Fon(300, 550, load_image('background.png'), self.include['fon'])

        self.mountain = Button(200, 50, 100, 100, load_image('mountain.png', -1), self.include['all'], self.include['buttons'])
        self.mountain.connect(self.goBattle)

        self.town = Button(25, 320, 50, 50, load_image('town.png', -1), self.include['all'], self.include['buttons'])
        self.town.connect(self.go_town)

        self.swamp = Button(200, 300, 100, 100, load_image('swamp.png', -1), self.include['all'], self.include['buttons'])
        self.swamp.connect(self.goBattle)

        self.forest = Button(0, 450, 100, 100, load_image('forest.png', -1), self.include['all'], self.include['buttons'])
        self.forest.connect(self.goBattle)

    def update(self, pos, *args):
        self.include['buttons'].update(pos, args)

    def draw(self):
        if (open("env/route.data", 'r').read() != "none"):
            if (open("env/route.data", 'r').read() != "mountain"):
                self.mountain.disable()
                self.mountain.image = pygame.transform.scale(load_image('mountainBlock.png', -1), (100, 100))
            else:
                self.mountain.enable()
                self.mountain.image = pygame.transform.scale(load_image('mountain.png', -1), (100, 100))
            if (open("env/route.data", 'r').read() != "forest"):
                self.forest.image = pygame.transform.scale(load_image('forestBlock.png', -1), (100, 100))
                self.forest.disable()
            else:
                self.forest.image = pygame.transform.scale(load_image('forest.png', -1), (100, 100))
                self.forest.enable()
            if (open("env/route.data", 'r').read() != "swamp"):
                self.swamp.image = pygame.transform.scale(load_image('swampBlock.png', -1), (100, 100))
                self.swamp.disable()
            else:
                self.swamp.image = pygame.transform.scale(load_image('swamp.png', -1), (100, 100))
                self.swamp.enable()
        else:   # --------------------------------------- если у нас нет квеста
            self.mountain.disable()
            self.mountain.image = pygame.transform.scale(load_image('mountainBlock.png', -1), (100, 100))
            self.swamp.image = pygame.transform.scale(load_image('swampBlock.png', -1), (100, 100))
            self.forest.image = pygame.transform.scale(load_image('forestBlock.png', -1), (100, 100))
            self.forest.disable()
            self.swamp.disable()
        self.include['fon'].draw(self.include['screen'])
        self.include['all'].draw(self.include['screen'])
        for q in self.include['lables']:
            q.draw(self.include['screen'])

    def go_town(self, *args):
        f = open('settings/location.data', 'w')
        f.write('town')
        f.close()

    def goBattle(self, *args):
        f = open('settings/lect.data', 'w')
        f.write('1')
        f.close()