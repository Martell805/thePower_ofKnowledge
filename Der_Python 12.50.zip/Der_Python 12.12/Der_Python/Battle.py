import pygame
from Defs import *
from Classes import *
import random


class Battle:
    def __init__(self, player, screen):
        self.gl_screen = screen
        self.loca = open('env/route.data')
        self.palyer = player
        self.enemy = Enemy(75, 75, 50, 50, load_image('default.png', -1),
                           random.randint(6, 12), random.randint(2, 4), random.randint(0, 6))
        f = open('settings/battle.data', 'w')
        f.write('0')

    def turn(self):
        self.all_sprites = pygame.sprite.Group()
        self.screen = pygame.Surface((300, 550))
        self.screen.fill((0, 0, 0))
        disc = open('settings/quest.data', 'r').read()

        self.fone_gr = pygame.sprite.Group()
        self.fon = Fon(300, 550, load_image('mount_fon.png', -1), self.fone_gr)

        lvl = open(disc + '/num.txt', 'r').read()
        pathh = disc + '/answers/' + lvl + '.txt'
        anss = open(pathh, 'r').readlines()
        r_ans = anss[0]
        anss = random.shuffle(anss)

        pathh = disc + '/tasks/' + lvl + '.txt'
        task = open(pathh, 'r').readlines()

        self.lables = []
        self.task = Label(80, 100, task, self.all_sprites, color=(0, 0, 0), size=10)

        # BODYYYYYYY

        self.fone_gr.draw(self.screen)
        self.all_sprites.draw(self.screen)
        for q in self.lables:
            q.draw()
        self.gl_screen.blit(self.screen, (0, 0))