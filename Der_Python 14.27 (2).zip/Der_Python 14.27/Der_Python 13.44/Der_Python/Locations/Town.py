import pygame
from Classes import *
from Defs import *


class Town:
    def __init__(self):
        self.include = {'buttons': pygame.sprite.Group(),
                        'all': pygame.sprite.Group(),
                        'lables': [],
                        'fon': pygame.sprite.Group(),
                        'screen': pygame.Surface((300, 550))}

        self.fon = Fon(300, 550, load_image('smallmap.png'), self.include['fon'])

        #self.lable1 = Label(100, 0, "POK", color=(255, 255, 255), size=20)
        #self.include['lables'].append(self.lable1)

        self.tavern = Button(0, 50, 139, 188, load_image('tavern.png', -1), self.include['all'], self.include['buttons'])
        self.tavern.connect(self.go_blank)

        self.shop = Button(120, 260, 166, 151, load_image('baraholka.png', -1), self.include['all'], self.include['buttons'])
        self.shop.connect(lambda x: print('Its baraholka'))

        self.gate = Button(150, 43, 38, 39, load_image('smallexit.png', -1), self.include['all'], self.include['buttons'])
        self.gate.connect(self.go_map)

        self.board = Button(70, 480, 96, 64, load_image('boardOfHonor.png', -1), self.include['all'], self.include['buttons'])
        self.board.connect(lambda x: print('Its board'))

    def update(self, pos, *args):
        self.include['buttons'].update(pos, args)

    def draw(self):
        self.include['fon'].draw(self.include['screen'])
        self.include['all'].draw(self.include['screen'])
        for q in self.include['lables']:
            q.draw(self.include['screen'])

    def go_map(self, *args):
        f = open('settings/location.data', 'w')
        f.write('map')
        f.close()

    def go_blank(self, *args):
        f = open('settings/blank_enabled.data', 'w')
        f.write('1')
        f.close()
