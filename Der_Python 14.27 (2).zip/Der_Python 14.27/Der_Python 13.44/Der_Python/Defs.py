import os
import pygame
import sys


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    image = pygame.image.load(fullname).convert()
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


def terminate():
    f = open('settings/location.data', 'w')
    f.write('map')
    f.close()
    f = open('settings/book_enabled.data', 'w')
    f.write('0')
    f.close()
    f = open('settings/book_enabled.data', 'w')
    f.write('0')
    f.close()
    f = open('settings/quest.data', 'w')
    f.write('NONE')
    f.close()
    f = open('settings/battle.data', 'w')
    f.write('909')
    f.close()
    #f = open('mat/num.txt', 'w')
    #f.write('0')
    #f.close()
    f = open('settings/blank_enabled.txt', 'w')
    f.write('0')
    f.close()
    pygame.quit()
    sys.exit()


def load_invent(file):
    return []
